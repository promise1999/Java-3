public class Shape {
    protected static String color;
    protected boolean filled;

    public Shape(){
        color = "red";
        filled = "false" != null;
    }
    public Shape(String color, boolean filled) {
        Shape.color = color;
        this.filled = filled;
    }
    
    // getters method
    public String getColor() {
        return color;
    }
    // setters method
    public void setColor(String color) {
        Shape.color = color;
    }
    public void isFilled(Boolean filled) {
        this.filled = filled;
    }
    public void setFilled(Boolean filled) {
        this.filled = filled;
    }
    @Override
    public String toString() {
        return "Shape[color = " + color + " filled / not filled = " + filled + "]";
    }
}
